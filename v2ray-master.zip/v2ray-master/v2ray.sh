#!/bin/bash

args=$@
is_sh_ver=v4.22

. /etc/v2ray/sh/src/init.sh
